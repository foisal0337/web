# Simple Portfolio
For new learners, learn html, css and build your first website. 

### A website for Programming Hero learners

To learn all these concepts as a absolute beginners, checkout: [Programming Hero](https://play.google.com/store/apps/details?id=com.learnprogramming.codecamp)